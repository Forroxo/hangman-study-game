# Configuração do Firebase

[Conteúdo mantido, movido da raiz]
