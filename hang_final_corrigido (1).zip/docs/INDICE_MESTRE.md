# 📚 ÍNDICE MESTRE - Toda a Documentação

[Conteúdo mantido, movido da raiz]
