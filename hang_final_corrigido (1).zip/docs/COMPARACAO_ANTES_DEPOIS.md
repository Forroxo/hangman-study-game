# ANTES vs DEPOIS - Código Corrigido Lado a Lado

[Conteúdo mantido, movido da raiz]
