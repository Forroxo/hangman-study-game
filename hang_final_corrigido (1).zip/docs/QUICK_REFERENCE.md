# 📝 QUICK REFERENCE - StudyHangman

[Conteúdo mantido, movido da raiz]
