# QUICK REFERENCE - Rotas Dinâmicas Next.js

[Conteúdo mantido, movido da raiz]
