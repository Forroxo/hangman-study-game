# 🛠️ GUIA TÉCNICO - StudyHangman

[Conteúdo mantido, movido da raiz]
